﻿using ArcusTel.PortalClientes.Api.DTO;

namespace ArcusTel.PortalClientes.Api.Interface;

public interface IPartnerBrasilClient
{
    Task<PartnerBrasilDidResponse?> ConsultaDidAsync(string did);
}
