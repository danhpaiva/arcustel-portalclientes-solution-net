﻿using ArcusTel.PortalClientes.Api.DTO;

namespace ArcusTel.PortalClientes.Api.Interface
{
    public interface IWorldTelClient
    {
        Task<WorldTelDidResponse?> ConsultarAsync(string did);
    }
}
