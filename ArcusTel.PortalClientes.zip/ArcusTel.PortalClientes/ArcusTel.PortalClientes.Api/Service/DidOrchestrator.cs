﻿using ArcusTel.PortalClientes.Api.Data;
using ArcusTel.PortalClientes.Api.Enum;
using ArcusTel.PortalClientes.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace ArcusTel.PortalClientes.Api.Service;

public class DidOrchestrator
{
    private readonly AppDbContext _db;
    private readonly PartnerBrasilClient _brClient;
    private readonly WorldTelClient _wtClient;

    public DidOrchestrator(
        AppDbContext db,
        PartnerBrasilClient brClient,
        WorldTelClient wtClient)
    {
        _db = db;
        _brClient = brClient;
        _wtClient = wtClient;
    }

    public async Task<DidOrchestratorResponse> ActivateDidAsync(string didNumber, long userId)
    {
        PartnerId partner = InferPartner(didNumber);

        // cria registro inicial
        var request = new DidActivationRequest
        {
            DidNumber = didNumber,
            PrefixCode = ExtractPrefix(didNumber),
            PartnerId = partner,
            RequestDate = DateTimeOffset.UtcNow,
            CurrentStatus = DidStatus.Pending,
            UserId = userId
        };

        _db.TB_DidActivationRequest.Add(request);
        await _db.SaveChangesAsync();

        // chama parceiro correspondente
        var result = partner switch
        {
            PartnerId.PartnerBrasil => await _brClient.ActivateDidAsync(request),
            PartnerId.WorldTel => await _wtClient.ActivateDidAsync(request),
            _ => throw new NotImplementedException()
        };

        // normaliza
        var normalizedStatus = await MapToNormalized(partner, result.PartnerStatus);

        // salva log
        var log = new PartnerResponseLog
        {
            RequestId = request.Id,
            Timestamp = DateTimeOffset.UtcNow,
            RawResponsePayload = result.RawPayload,
            PartnerStatus = result.PartnerStatus,
            NormalizerOutputStatus = normalizedStatus,
            PartnerDetailMessage = result.Message
        };

        _db.TB_PartnerResponseLog.Add(log);

        // atualiza o request
        request.CurrentStatus = normalizedStatus;
        request.LastPartnerRawStatus = result.PartnerStatus;

        await _db.SaveChangesAsync();

        return new DidOrchestratorResponse
        {
            RequestId = request.Id,
            DidNumber = didNumber,
            Partner = partner.ToString(),
            Status = normalizedStatus,
            DetailMessage = result.Message
        };
    }

    // 🔧 Helpers
    private PartnerId InferPartner(string did)
    {
        if (did.StartsWith("+55")) return PartnerId.PartnerBrasil;
        return PartnerId.WorldTel;
    }

    private string ExtractPrefix(string did)
    {
        if (did.StartsWith("+55"))
            return did.Substring(0, 4); // ex: +5511
        return did.Substring(0, 5);     // internacional
    }

    private async Task<DidStatus> MapToNormalized(PartnerId partner, string partnerStatus)
    {
        var map = await _db.TB_PartnerStatusMapping
            .FirstOrDefaultAsync(m =>
                m.PartnerId == partner &&
                m.PartnerExternalStatus == partnerStatus);

        return map?.InternalNormalizedStatus ?? DidStatus.Unknown;
    }
}
